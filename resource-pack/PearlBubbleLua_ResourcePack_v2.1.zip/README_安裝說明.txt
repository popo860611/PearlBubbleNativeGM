﻿PearlBubbleLua Resource Pack v2.1

用途：補齊另一台電腦缺少的：
tmpNew\Lua\PearlBubbleLua\main.lua

安裝：
1. 關閉 StarMJ371 與 PearlBubbleNativeGM。
2. 解壓縮整個 ZIP。
3. 執行 INSTALL_RESOURCES.bat。
4. 確認顯示 SUCCESS。
5. 再回到 GM 安裝包執行 INSTALL.bat、CHECK_STATUS.bat。

也可手動把 ZIP 裡的 tmpNew 資料夾複製到遊戲根目錄，例如 D:\明星\StarAIO。
注意：這份資源取自目前測試中的同版本客戶端，包含 Native GM v2.1 的 main.lua 與 NativeGMBridge.lua。