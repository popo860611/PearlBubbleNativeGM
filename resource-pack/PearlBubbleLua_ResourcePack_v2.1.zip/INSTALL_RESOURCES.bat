@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "DEFAULT_ROOT=D:\明星\StarAIO"
echo ==================================================
echo   PearlBubbleLua Resource Pack v2.1
echo ==================================================
echo.
set /p "GAME_ROOT=Game folder [D:\明星\StarAIO]: "
if not defined GAME_ROOT set "GAME_ROOT=%DEFAULT_ROOT%"
if not exist "%~dp0tmpNew\Lua\PearlBubbleLua\main.lua" (
  echo ERROR: Resource payload is incomplete.
  pause
  exit /b 1
)
if not exist "%GAME_ROOT%" mkdir "%GAME_ROOT%"
if not exist "%GAME_ROOT%\tmpNew\Lua\PearlBubbleLua" mkdir "%GAME_ROOT%\tmpNew\Lua\PearlBubbleLua"
robocopy "%~dp0tmpNew\Lua\PearlBubbleLua" "%GAME_ROOT%\tmpNew\Lua\PearlBubbleLua" /E /R:1 /W:1 >nul
if errorlevel 8 (
  echo ERROR: Copy failed. Robocopy exit code %ERRORLEVEL%.
  pause
  exit /b 1
)
if not exist "%GAME_ROOT%\tmpNew\Lua\PearlBubbleLua\main.lua" (
  echo ERROR: main.lua was not installed.
  pause
  exit /b 1
)
echo.
echo SUCCESS: PearlBubbleLua resources installed to:
echo %GAME_ROOT%\tmpNew\Lua\PearlBubbleLua
echo.
echo Next: run INSTALL.bat from the GM package, then CHECK_STATUS.bat.
pause
exit /b 0